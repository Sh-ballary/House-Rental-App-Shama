# House-Rent(frontend)

for details click [here](https://github.com/rjarman/House-Rent/blob/master/README.md)